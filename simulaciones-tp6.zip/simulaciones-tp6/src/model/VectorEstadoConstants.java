/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author heftyn
 */
public interface VectorEstadoConstants 
{
    int COL_RELOJ = 0;
    int COL_EVENTO = 1;
    int COL_LLEGADA_ALUMNO_RND = 2;
    int COL_LLEGADA_ALUMNO_TIEMPO = 3;
    int COL_LLEGADA_ALUMNO_PROXIMA = 4;
    int COL_LLEGADA_MANTENIMIENTO_RND = 5;
    int COL_LLEGADA_MANTENIMIENTO_TIEMPO = 6;
    int COL_LLEGADA_MANTENIMIENTO_PROXIMO = 7;
    int COL_FIN_MANTENIMIENTO_RND = 8;
    int COL_FIN_MANTENIMIENTO_CANTIDAD_ARCHIVOS = 9;
    int COL_FIN_MANTENIMIENTO_TIEMPO = 10;
    int COL_FIN_MANTENIMIENTO_PROXIMO = 11;
    int COL_COLA = 12;
    int COL_FIN_INSCRIPCION_RND = 13;
    int COL_FIN_INSCRIPCION_TIEMPO = 14;
    int COL_MAQUINA_1_ESTADO = 15;
    int COL_MAQUINA_1_AC_INSCRIPTOS = 16;
    int COL_MAQUINA_1_HORA_FIN_INSCRIPCION = 17;
    int COL_MAQUINA_1_FUE_MANTENIDA = 18;
    int COL_MAQUINA_2_ESTADO = 19;
    int COL_MAQUINA_2_AC_INSCRIPTOS = 20;
    int COL_MAQUINA_2_HORA_FIN_INSCRIPCION = 21;
    int COL_MAQUINA_2_FUE_MANTENIDA = 22;
    int COL_MAQUINA_3_ESTADO = 23;
    int COL_MAQUINA_3_AC_INSCRIPTOS = 24;
    int COL_MAQUINA_3_HORA_FIN_INSCRIPCION = 25;
    int COL_MAQUINA_3_FUE_MANTENIDA = 26;
    int COL_MAQUINA_4_ESTADO = 27;
    int COL_MAQUINA_4_AC_INSCRIPTOS = 28;
    int COL_MAQUINA_4_HORA_FIN_INSCRIPCION = 29;
    int COL_MAQUINA_4_FUE_MANTENIDA = 30;
    int COL_MAQUINA_5_ESTADO = 31;
    int COL_MAQUINA_5_AC_INSCRIPTOS = 32;
    int COL_MAQUINA_5_HORA_FIN_INSCRIPCION = 33;
    int COL_MAQUINA_5_FUE_MANTENIDA = 34;
    int COL_AC_INSCRIPCIONES = 35;
    int COL_AC_ALUMNOS_QUE_LLEGAN = 36;
    int COL_AC_ALUMNOS_QUE_SE_VAN = 37;
    int COL_ENCARGADO_ESTADO = 38;
    
}