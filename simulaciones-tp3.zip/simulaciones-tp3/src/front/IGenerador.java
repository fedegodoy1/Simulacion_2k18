/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package front;

/**
 *
 * @author nicolashefty
 */
public interface IGenerador
{
 public void setVisible(boolean visible);
 public void setGeneratorType(String type);
 public String getGeneratorType();
}
